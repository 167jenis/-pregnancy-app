import { IonContent, IonHeader, IonIcon } from '@ionic/react'
import React from 'react'
import { useHistory } from 'react-router'
import "./me.css"

export const BirthPlan = () => {
    const history = useHistory();
    return (
        <IonContent>
            <IonHeader>
             
            </IonHeader>
            <div>Hii</div>
        </IonContent>
    )
}
