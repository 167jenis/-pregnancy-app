// import { IonContent, IonHeader } from '@ionic/react'
// import React from 'react'
// import { useHistory } from 'react-router'
// import TellAFriends from "../../assets/images/tellAFriend.jpg"


// export const TellAFriend = () => {
//     return (
//         <IonContent>
//             <div>
//                 <img src={TellAFriends} />
//             </div>
//         </IonContent>
//     )
// }
